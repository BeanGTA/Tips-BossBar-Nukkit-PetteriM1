package tip.messages;


/**
 * @author SmallasWater
 */
@Deprecated
public class NameTagMessage extends tip.messages.defaults.NameTagMessage {

    public NameTagMessage(String worldName, boolean open, String message) {
        super(worldName, open, message);
    }
}
