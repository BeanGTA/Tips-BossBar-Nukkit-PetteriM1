package tip.utils.variables.defaults;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * 修改 获取传入的字符串，并修改
 * @author SmallasWater*/
@Retention(RetentionPolicy.RUNTIME)
@Deprecated
public @interface ChangeMessage {}
